﻿using System;

namespace UnitTestEmployeeEx
{
    internal class TestClassAttribute : Attribute
    {
    }
}