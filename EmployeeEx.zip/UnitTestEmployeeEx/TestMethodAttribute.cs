﻿using System;

namespace UnitTestEmployeeEx
{
    internal class TestMethodAttribute : Attribute
    {
    }
}